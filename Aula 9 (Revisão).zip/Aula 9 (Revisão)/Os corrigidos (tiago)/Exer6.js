// Simulação de uma fila de atendimento com prioridade para clientes acima de 60 anos

let filaNormal = new Fila();
let filaPreferencial = new Fila();
function enfileirar(nome, idade) {
 if (idade >= 60) filaPreferencial.enqueue(nome);
 else filaNormal.enqueue(nome);
}
function atender() {
 if (!filaPreferencial.isEmpty()) return
filaPreferencial.dequeue();
 return filaNormal.dequeue();
}
enfileirar("Dona Maria", 65);
enfileirar("Carlos", 30);
enfileirar("Seu João", 70);
enfileirar("Ana", 25);
while (!filaNormal.isEmpty() || !filaPreferencial.isEmpty()) {
 console.log("Atendendo:", atender());
}