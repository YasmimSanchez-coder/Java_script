/*Um mágico embaralha 5 cartas com os valores A, B, C, D, E e as empilha. Peça aos
alunos para simular o processo de colocar as cartas na pilha (push) e depois revelar
a ordem em que saem (pop), mostrando que o último a entrar é o primeiro a sair
(LIFO). Desafio extra: inverter a ordem da pilha usando uma segunda pilha.*/

let stack = [];
let cartas = ['A', 'B', 'C', 'D', 'E'];
// Empilhando
for (let carta of cartas) {
 stack.push(carta);
}
console.log("Pilha completa:", stack);
// Desempilhando
while (stack.length > 0) {
 console.log("Retirando carta:", stack.pop());
}