const Grafo = require ('./Grafo.js');

const meugrafo=new Grafo();

meugrafo.adicionarVertice('Tiago');
meugrafo.adicionarVertice('Talita');
meugrafo.adicionarVertice('João');
meugrafo.adicionarVertice('Marina');
meugrafo.adicionarVertice('Pedro');
meugrafo.adicionarVertice('Tereza')

meugrafo.adicionarAresta('Tiago', 'Talita');
meugrafo.adicionarAresta('Tiago', 'João');
meugrafo.adicionarAresta('Talita', 'João');
meugrafo.adicionarAresta('Marina', 'Pedro');
meugrafo.adicionarAresta('Tereza', 'Pedro');
meugrafo.adicionarAresta('João', 'Talita');

meugrafo.imprimirgrafo();