class MeuArray {
  constructor() {
    this.items = {}; //usamos um objecto para armazenar os itens do array
    this.tamanho = 0; //mantemos o controle do tamanho do array
  }


  //adiciona um elemento ao final do array
  adicionar(elemento) {
    this.items[this.tamanho] = elemento; //insere o elemento na posição atual do tamanho
    this.tamanho++; //Incrementa o tamanho
  }

  //Remove o último elemento do array
  remove() {
    if (this.tamanho === 0) {
      return undefined; //se o array estiver vazio, não há o que remover
    }
    const ultimoitem = this.items[this.tamanho - 1]; //armazena o ultimo item
    delete this.items[this.tamanho - 1]; //remove o ultimo item do array
    this.tamanho--; //Decrementa o tamanho

    return ultimoitem; //retorna o item removido
  }
  //Acessa o elemento em um índice especifico
  obterElemento(indice) {
    if (indice < 0 || indice >= this.tamanho) {
      return undefined; //se o indice estive fora do alcance, retorna undefined
    }
    return this.items[indice]; //Retorna o item no indice solicitado
  }
  //retorna o tamanho do array
  tamanhoArray() {
    return this.tamanho; //retorna o valor do tamanho atual do array
  }

  //remove todos os elementos do array
  limpar() {
    this.item = {}; //limpa o objeto
    this.tamanho = 0; //reinicializa o tamanho
  }
}

//Exemplo de uso

let minha_variavel = new MeuArray();

minha_variavel.adicionar(10);
console.table(minha_variavel.items); //ele cria uma tabelinha fofa

minha_variavel.adicionar(20);
console.table(minha_variavel.items);

minha_variavel.adicionar(30);
console.table(minha_variavel.items);

console.log(minha_variavel.obterElemento(1)); //Saída: 20
console.log(minha_variavel.tamanhoArray()); //Saída: 3

console.log(minha_variavel.remove()); //Saída: 30 (Remove o ultimo elemento)
console.log(minha_variavel.tamanhoArray()); //Saída: 2

//caso de erro ver se está tudo minusculo PFV

//Exercicio 1 (Criando uma instancia)
const tarefa = new MeuArray();

//Adicionando cinco tarefas ao array
tarefas.adicionar("Revisar relatorio financeiro");
tarefas.adicionar("Preparar apresentação para a diretoria");
tarefas.adicionar("Responder e-mails pendentes");
tarefas.adicionar("Agendar reunião com fornecedores");
tarefas.adicionar("Atualizar documentaçoes internas");

//removendo a ultima tarefa adiconada
console.log("Tarefa removida:", tarefas.remove());

//exibindo todas as tarefas armazenadas
console.log("Lista de tarefas:");
for (let i = 0; i < tarefas.tamanhoArray(); i++){
  console.log(tarefas.obterElemento(i));
}

//Exercicio 2 (criando uma uma instancia)
const participantes =  new MeuArray();

//Adicionando os nomes dos quatro funcionarios
participantes.adicionar("Carlos");
participantes.adicionar("Ana");
participantes.adicionar("Roberto");
participantes.adicionar("Fernanda");

//obtendo o nome do terceiro funcionario que participou
console.log("Terceiro participantes:", participantes.obterElemento(2));

//limpando todos os registros do array
participantes.limpar();

//tentando acessar um indice após limpar o array
console.log("Tentando acessar após limpar:", participantes.obterElemento(0));