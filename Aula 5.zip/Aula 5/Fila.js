class Fila {
    constructor()
    {
    this.items();
    // Usamos um objeto para armazenar os itens
    this.inicio = 0;
    // Representa o indice do inicio da fila
    this.fim = 0;
    // Representa o indice do fim de fila
    }
    // Adiciona um elemento ao final da fila (enqueue)
    enqueue(elemento)
    {
    this.items[this.fim] = elemento;
    // Coloca o elemento no fim da fila
    this.fim++; // Incrementa o indice do fim da fila
    }
}

//Remove & retorna o primeiro elemento da FLLa (dequeue)
dequeue()
{
    if (this.isEmpty())
      return undefined;  //Se a fila estiver vazia, retorna undefined
}
{
const iten = this.items[this.inicio];
//Obtém o primeiro elemento
delete this.items[this.inicio]; //Remove a iten do inicio da fila
this.inicio++; //Houve o indice do início para o próxino iten

// Quando o início e o fin estiveren alinhados, redefine a fila
if (this.inicio === this.fim) {
    this.inicio = 0;
    this.fim = 0;
}
return $ten; // Retorna o iten renovido
}
// Retorna o prineiro elemento da fila sen renová-lo (peek)
front()
{
if (this.isEmpty()) {
return undefined; // Se a fils estiver vazia, retorna undefined
}
return this.items[this.inicio]; // Retorna o primeiro elemento
}

// Remove e retorna o primeiro elemento da fila (dequeue)
dequeue()
{
    if (this.isEmpty()){
return undefined;
// Se a fila estiver vazia, retorna undefined
    }
    const item=this.items[this.inicio]; // Obtém o primeiro elemento
    delete this.items[this.inicio]; //Remove o item do início da fila
    this.inicio++; // Move o índice do início para o próximo item

// Quando o início e o fim estiveren alinhados, redefine a fila
if (this.inicio === this.fim) {
     this.inicio=0;
     this.fim=0;
}

return item; // Retorna o item removido

}
// Retorna o primeiro elemento da fila sen removê-lo (peek)
front()
{
   if (this.isEmpty()) {
      return undefined; // Se a fila estiver vazia, retorna undefined 
    } 
    return this.items[this.inicio]; // Retorna o primeiro elemento
}


// Verifica se a fila está vazia
isEmpty()
{ 
return this.fim === this.inicio; // Verifica se os índices estão iguais
}

// Retorna o tamanho da fila
size()
{
    return this.fim - this.inicio; // Calcula a diferença entre fim e início
}

clear() // Limpa a fila
{
this.items = {};
this.inicio = 0;
this.fim = 0;
}

// Exemplo de uso
let minha_variavel = new Fila();

minha_variavel.enqueue("Cliente 1");
minha_variavel.enqueue("Cliente 2");
minha_variavel.enqueue("Cliente 3");

console.log(minha_variavel.front()); // Saída: "Cliente 1"

console.log(minha_variavel.dequeue()); // Saída: "Cliente 1"
console.log(minha_variavel.dequeue()); // Saída: "Cliente 2"

minha_variavel.enqueue("Cliente 4");

console.log(minha_variavel.size()); // Saída: 2 (Cliente 3 e Cliente 4 ainda estão na fila)
console.log(minha_variavel.front()); // Saida: "Cliente 3"