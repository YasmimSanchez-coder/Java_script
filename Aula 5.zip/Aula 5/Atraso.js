console.log("Mensagem 1");

setTimeout(function() {
     console.log("Mensagem 2");
}, 2000); //2000 milissegundos = 2 segundos

console.log("Mensagem 3");