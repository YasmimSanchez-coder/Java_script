class Sorter{

    //bubble sort
    static bubbleSort(arr){
        const array = [...arr]; //copia para não alterar o original
        let n = array.length;
        let trocou;

        do{
            trocou = false;
            for(let i = 0; i < n - 1; i++){
                if(array[i] > array[i+1]){
                    [array[i], array[i + 1]] = [array[i+1], array[i]];
                    trocou = true;
                }
            }
            n--;
        }while (trocou);

        return;
    }

    //Quick Sort
    static quickSort(arr){
        if(arr.length <= 1) return arr;

        const pivot = arr[arr.length - 1];
        const menores = [];
        const maiores = [];

        for(let i =0; i < arr.length - 1; i++){
            if(arr[i] < pivot){
                menores.push(arr[i]);
            } else {
                maiores.push(arr[i]);
            }
        }

        return [...Sorter.quickSort(menores), pivot, ...Sorter.quickSort(maiores)];
    }

    //merger sort
    static mergeSort(arr){
        if (arr.length <= 1) return arr;

        const meio = Math.floor(arr.length / 2);
        const esquerda = Sorter.mergeSort(arr.slice(0, meio));
        const direta = Sorter.mergeSort(arr.slice(meio));

        return Sorter.mergeSort(esquerda, direita);    
    }
}