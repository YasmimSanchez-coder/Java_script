//Exemplo comparativo: Usando Object
const dicionario6 = {};
dicionario6["nome"] = "Yasmim";
dicionario6[19] = "Número";

//Acesso
console.log(dicionario6["nome"]); //Saída: Yasmim
console.log(dicionario6["19"]); //Saída: Número (chaves numéricas convertidas para string)

//Interação
for (const chave in dicionario){
    console.log(`${chave}: ${dicionario6[chave]}`);
}

//Exemplo comparativo: Usando Map
const mapa = new Map();
mapa.set("nome", "Yasmim");
mapa.set(19, "Número");

//Acesso
console.log(mapa.get("nome")); //Saída: Yasmim
console.log(mapa.get(19)); //Saída: Número

//Iteração
for(const[chave,valor] of mapa){
    console.log(`${chave}: ${valor}`);
}