// Criando um dicionário com um objeto
const dicionario1 = {
    nome: "Yasmim",
    idade: 19,
    profissao: "Programadora"
};

console.log(dicionario1.nome); //Saída:Yasmim
console.log(dicionario1["idade"]); //Saída:19

//Dicionários com objetos
const dicionário2 = {};

//Adicionando chaves e valores
dicionário2["cor"] = "amarelo";
dicionário2.tamanho = "grande";

console.log(dicionário2); //Saída: { cor: 'azul', tamanho: 'grande' }

//Removendo uma chave
delete dicionário2["cor"];
console.log(dicionário2); //Saída: {tamanho: 'grande' }

//iterando sobre um dicionário
const dicionário3 = {
    fruta: "Uva verde",
    cor: "Verde",
    preco: 10
};

//Usando `for...in`
for(const chave in dicionário3){
    console.log(`${chave}: ${dicionário3[chave]}`);
}

//Metodos pra trabalhar com o dicionário
const dicionário4 = {
    nome: "Yasmim",
    idade: 19,
    cidade: "Jáu"
};

//Obter todas as chaves
console.log(Object.keys(dicionário4)); //Saída: ["nome", "idade", "cidade"]

//Obter todos os valores
console.log(Object.values(dicionário4)); //Saída: ["Yasmim", 19, "Jáu"]

//Obter pares chave-valor
Object.entries(dicionário4).forEach(([chave, valor]) => {
    console.log(`${chave}: ${valor}`);
})

//Validando e trabalhando com chaves
const dicionário5 = { fruta: "Uva verde" };

if("fruta" in dicionário5){
    console.log("Chave encontrada!");
} else {
    console.log("Chave não encontrada!");
}
 const dados = { nome: "Yasmim" };

 if (!("Idade" in dados)) {
    dados["idade"] = 28;
 }

 console.log(dados); //Saída: {nome: "Yasmim", idade: 28}

 //Dicionários com a classe map
 const map = new Map();

 //Adicionando pares chave-valor
 mapa.set("nome", "Rayssa");
 mapa.set("idade", 18);

 //Obtendo valores
 console.log(mapa.get("nome")); //Saída: Rayssa

 //Verificando se uma chave existe
 console.log(mapa.has("idade")); //Saída: true

 //Removendo um chave
 mapa.delete("idade");
 console.log(mapa.has("idade")); //Saída: false

 //Dicionários com a classe map - iterando

const mapa = new Map([
    ["chave1", "valor1"],
    ["chave2", "valor2"]
]);

//Iterando com for...of
for (const [chave, valor] of mapa){
    console.log(`${chave}: ${valor}`);
}