//Exercicio 1
class SpellStack{
    constructor(){
        this.spells = [] //Inicializa a pilha de feitiços
    }

    //Adiciona um novo feitiço no topo
    addSpell(spells){
        this.spells.push(spell); //Adiciona o feitiço no topo
        console.log(`Feitiço"${spell}" adicionado!`);
    }

    //Remove e retorna o feitiço do topo
    removeSpell(){
        if (this.isEmpaty()){
            console.log("Nenhum feitiço na torre!");
            return;
        }
        console.log(`Feitiço "${this.spells.pop()}" removido!`);
    }
//Mostra o feitiço no topo sem removê-lo
peekSpell(){
    if (this.isEmpaty()) {
        console.log("Nenhum feitiço para ver!");
    }
    console.log(`Feitiço no topo: "${this.spells[this.spells.length - 1]}"`);
}

//verifica se a pilha de feitiços está vazia
 isEmpaty(){
    return this.spells.length === 0;
 }
}

const tower = new SpellStack();
tower.addSpell("Bola de fogo");
tower.addSpell("Escudo Arano");
tower.peekSpell(); //"Escudo Arcano"
tower.removeSpell(); //"Escudo Arcano" removido
tower.removeSpell(); //"Bola de fogo" removido
tower.removeSpell(); //Nenhum feitiço na torre!