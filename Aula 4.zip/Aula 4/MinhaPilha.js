class MinhaPilha{
   
constructor(){
     this.items = {};  //Usamos um objeto para armazenar os elementos da pilha
     this.tamanho = 0;  //Mantemos o controle do tamanho da pilha
 }

//Adicionar um elemento ao topo da pilha
adicionar(elemento)
 {
    this.items[this.tamanho] = elemento; //Insere o elemento na posição atual do tamanho
    this.tamanho++; //Incrementa o tamanho
 }

//Remove e retorna o elemento do topo da pilha
remover()
 {
   if (this.tamanho ===0){
        return undefined; //Se a pilha estiver vazia, retorna undefined
   }

   const ultimoitem = this.items[this.tamanho - 1]; //Pega o item no topo da pilha
   delete this.items[this.tamanho - 1]; //Remove o item do topo
   this.tamanho--; //Decrementa o tamanho

   return ultimoitem; //Retorna o item removido
 }

//Retorna o elemento no topo da pilha SEM removê-lo
topo()
 {
    if(this.tamanho === 0){
        return undefined; //se a pilha estiver vazia..
    }
    return this.items[this.tamanho - 1]; //Retorna..
 }

//Verifica se a pilha está vazia
estaVazia()
 {
    return this.tamanho === 0; //verifica se o tamanho..
 }

//Retorna o número de elementos na pilha
tamanhoPilha()
 {
    return this.tamanho; //Retorna o tamanho da pilha..
 }

//Limpa a pilha
limpar()
 {
    this.items = {} //Reseta os itens
    this.tamanho = 0; //Reinicializa o tamanho
 }
}

//Exemplo de uso
let minha_variavel = new MinhaPilha();

minha_variavel.adicionar(10);
minha_variavel.adicionar(20);
minha_variavel.adicionar(30);

console.log(minha_variavel.topo()); //Saída: 30 (Elemento no topo)

console.log(minha_variavel.remover()); //Saída: 30 (Remove o elemento do topo)
console.log(minha_variavel.topo()); //Saída: 20 (Agora o topo é 20)

console.log(minha_variavel.tamanhoPilha()); //Saída: 2(Dois elementos restantes)

//Exercicio 1
class SpellStack{
    constructor(){
        this.spells = [] //Inicializa a pilha de feitiços
    }

    //Adiciona um novo feitiço no topo
    addSpell(spells){
        this.spells.push(spell); //Adiciona o feitiço no topo
        console.log(`Feitiço"${spell}" adicionado!`);
    }

    //Remove e retorna o feitiço do topo
    removeSpell(){
        if (this.isEmpaty()){
            console.log("Nenhum feitiço na torre!");
            return;
        }
        console.log(`Feitiço "${this.spells.pop()}" removido!`);
    }
//Mostra o feitiço no topo sem removê-lo
peekSpell(){
    if (this.isEmpaty()) {
        console.log("Nenhum feitiço para ver!");
    }
    console.log(`Feitiço no topo: "${this.spells[this.spells.length - 1]}"`);
}

//verifica se a pilha de feitiços está vazia
 isEmpaty(){
    return this.spells.length === 0;
 }
}

const tower = new SpellStack();
tower.addSpell("Bola de fogo");
tower.addSpell("Escudo Arano");
tower.peekSpell(); //"Escudo Arcano"
tower.removeSpell(); //"Escudo Arcano" removido
tower.removeSpell(); //"Bola de fogo" removido
tower.removeSpell(); //Nenhum feitiço na torre!