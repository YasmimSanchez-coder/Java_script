function saudacao(nome)
{
    let msg = "Olá " + nome;
    console.log(msg);
}
saudacao("João"); //Olá ...