//Rpetição PARA
for(let i = 0; i < 10; i++){
    console.log("o valor de i é  " + i);
}