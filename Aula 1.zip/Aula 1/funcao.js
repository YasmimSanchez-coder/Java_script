function somar(a, b)
{
    let res = a + b;
    return res;
}

console.log( somar(2, 3) ); //5