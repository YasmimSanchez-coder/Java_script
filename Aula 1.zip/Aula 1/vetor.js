//Declaração de Vetor
let nomes = [];
nomes[0] = "João";
nomes[1] = "Maria";
nomes[2] = "José";
//Acessando cada posição do vetor
for (let i = 0; i < 3; i++) {
     console.log(nomes[i]);
}