//nó = vértice = cidade
//estrada = aresta
//peso = distancia (km)

class GrafoPonderado{
    constructor(){
        //conjunto de vertices unicos
        this.vertices = new Set();

        //Mapa onde casa vértice aponta para uma lista de objectos: {vertice, peso}
        this.adjacencia = new Map();
    }

    //Adicionar um novo vértice ao grafo. Se já existir, nada é feito.
    //também inicializa sua lista de adjacência.
    adicionarVertice(v){

        //Garante que o vértice está no conjunto
        this.vertices.add(v);
        if (!this.adjacencia.has(v)){ //! = não, se não..

            //inicializa lista de vizinhos se ainda não existir
            this.adjacencia.set(v, []);
        }
    }

    //adiciona uma aresta ponderada entre dois vertices.
    //cria os vértices caso ainda não existam. por padrão, é um grafo direcionado.
    adicionarAresta(origem, destino, peso){
        if (!this.adjacencia.has(origem)) this.adjacenciaVertice(origem);
        if (!this.adjacencia.has(destino)) this.adicionarVertice(destino);

        this.adjacencia.get(origem).push({ vertice: destino, peso});

    //se o grafo for não-direcioado, descomente a linha abaixo:
    //this.adjacencia.get(destino).push({ vertice: origem, peso});
    }

    //mostra a representação do grafo como lista de adjacência, como os pesos vísiveis.
    imprimirGrafo(){
        for (const [v, vizinho] of this.adjacencia.entries()){
        const lista = vizinho.map(obj => `${obj.vertice}(${obj.peso})`).join(', ');
        console.log(`${v} - > ${lista}`);
    }   
}
    //gera e imprime a matriz de adjacencia do grafo.
    //usa infinity para representar ausência de aresta.
    imprimirMatrizAdjacencia(){
        const vertices = Array.from(this.vertices);
        const n = vertices.length;
        const matriz = Array.from({ length: n}, () => Array(n).fill(infinity));

        vertices.forEach((v, i) => {
            matriz[i][i] =  0; //distancia entre si mesmo = 0
            for (const vizinho of this.adjacencia.get (v)){
                const j = vertices.indexOf(vizinho.vertice);
                matriz[i][j] = vizinho.peso;
            }
        });

        console.log('Matriz de Adjacência (valores infinitos representam ausência de aresta):');
        console.log('  ', vertices.join('  '));
        matriz.forEach((linha, i) => {
            console.log(vertices[i], linha.map(x => x === infinity ? 'infinito': x). join('  '));
        });
    }

    //busca em profundidade (Depth-Frist Seach)
    //realiza uma busca em profundidade, visitando o vertice inicial e seus vizinhos recursivamente até esgotar caminhos.
    dfs(inicio){
        const visitados = new set();
        const resultado = [];

        const visitar = (v) =>{
            visitados.add(v);
            resultado.push(v);

            for (const vizinho of this.adjacencia.get(v)){
                if (!visitandos.has(vizinho.vertice)){
                    visitar(vizinhp.vertice);
                }
            }
        };

        visitar (inicio);
        console.log('DFS:', resultado.join(' -> '));
    }

    //busca em largura (breadth-firts search)
    //realiza uma busca em largura, explorando primeiro os vizinhos mais próximos, usando uma fila.
    bfs(inicio){
        const visitados = new Set();
        const fila = [inicio];
        const resultado = [];

        visitados.add(inicio);

        while(fila.length > 0){
            const atual = fila.shift();
            resultado.push(atual);

            for (const vizinho of this.adjacencia.get(atual))
                if(!visitados.has (vizinho.vertice)){
                    visitados.add(vizinho.vertice);
                    fila.push(vizinho.vertice);
                }
        }

        console.log('BFS:', resultado.join(' -> '));
    }

    //algoritimo de Dijkstra paar encontrar o caminho mais curto
    //calcula as menores distãncias entre os vértices inicial e todos os demais, com base nos pesos das arestas
    //usa a abordagem clássico de Dijkstra.
    dijkstra(inicio){
        const distancias = {};
        const anteriores = {};
        const naoVisitados = new Set(this.vertices);

        for (const v of this.vertices){
            distancias[v] = infinity;
            anteriores[v] = null;
        }
        distancias[inicio] = 0;

        while (naoVisitados.size > 0){
            //encontrar o vértice não visitado com a menor distancia conhecida
            const atual = [...naoVisitados].reduce((a, b) =>
                distancias[a] < distancias[b] ? a : b
            );
            naoVisitados.delete(atual);

            //atualiza ditãncias para vizinhos
            for(const vizinhos of this.adjacencia.get(atual)){
                const alt = distancias[atual] + vizinho.peso;
                if (alt < distancias[vizinho.vertice]){
                    distancias[vizinho.vertice] = alt;
                    anteriores[vizinho.vertice] = atual;
                }
            }
        }

        //exibe o resultado
        console.log(`menores distancias a partir de ${inicio}:`);
        for(const v of this.vertices){
            console.log(`${v}: ${distancias [v]}`);
        }
    } //fecha dijkstra
    //fecha grafo ponderado
}

//exporta a classe pra uso em outros módulos
module.exports = GrafoPonderado;
