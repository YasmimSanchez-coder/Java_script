//Classe Node para representar um nó na árvore binária
class Node{
    constructor(value){
        this.value = value; //Valor armazenado no nó
        this.left = null; //Referência para o nó filho á esquerda
        this.right = null; //Rferência para o nó filho á direita
    }

}

//Constructor
//Classe binaryTree para representar o árvore binária
class BinartTree{

    constructor(){
        this.root = null; //Inicialmente, a árvore está vazia, então a raiz é null
    }
}